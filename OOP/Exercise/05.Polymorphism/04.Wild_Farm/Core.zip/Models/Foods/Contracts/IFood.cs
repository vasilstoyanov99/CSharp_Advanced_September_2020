﻿
namespace _04.Wild_Farm.Models.Foods.Contracts
{
    public interface IFood
    {
        public int Quantity { get; }
    }
}

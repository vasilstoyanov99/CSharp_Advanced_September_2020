﻿
namespace _04.Wild_Farm.Models.Foods
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {

        }
    }
}

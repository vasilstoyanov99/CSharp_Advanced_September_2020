﻿
namespace _04.Wild_Farm.Models.Animals.Contracts
{
    public interface IFeline
    {
        public string Breed { get; }
    }
}

﻿
namespace _04.Wild_Farm.Models.Animals.Contracts
{
    public interface IBird
    {
        double WingSize { get; }
    }
}

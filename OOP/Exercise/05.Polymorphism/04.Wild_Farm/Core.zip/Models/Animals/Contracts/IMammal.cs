﻿
namespace _04.Wild_Farm.Models.Animals.Contracts
{
    public interface IMammal
    {
        public string LivingRegion { get; }
    }
}

﻿
namespace _04.Wild_Farm.Global
{
    public class AskForFoodSounds
    {
        public const string OWL_ASK_FOR_FOOD_SOUND = "Hoot Hoot";
        public const string HEN_ASK_FOR_FOOD_SOUND = "Cluck";
        public const string MOUSE_ASK_FOR_FOOD_SOUND = "Squeak";
        public const string DOG_ASK_FOR_FOOD_SOUND = "Woof!";
        public const string CAT_ASK_FOR_FOOD_SOUND = "Meow";
        public const string TIGER_ASK_FOR_FOOD_SOUND = "ROAR!!!";

    }
}

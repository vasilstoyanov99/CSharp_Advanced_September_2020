﻿
namespace _04.Wild_Farm.Global
{
    public class Messages
    {
        public const string DOES_NOT_EAT_THIS_TYPE_OF_FOOD = "{0} does not eat {1}!";
    }
}

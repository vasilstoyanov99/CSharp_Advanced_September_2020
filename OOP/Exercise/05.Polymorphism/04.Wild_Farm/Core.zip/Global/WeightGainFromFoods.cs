﻿
namespace _04.Wild_Farm.Global
{
    public class WeightGainFromFoods
    {
        public const double HEN_WEIGHT_GAIN = 0.35;
        public const double OWL_WEIGHT_GAIN = 0.25;
        public const double MOUSE_WEIGHT_GAIN = 0.10;
        public const double CAT_WEIGHT_GAIN = 0.30;
        public const double DOG_WEIGHT_GAIN = 0.40;
        public const double TIGER_WEIGHT_GAIN = 1.00;
    }
}

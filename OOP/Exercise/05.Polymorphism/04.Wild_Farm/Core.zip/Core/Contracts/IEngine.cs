﻿
namespace _04.Wild_Farm.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}

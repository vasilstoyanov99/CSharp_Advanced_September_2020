﻿
using _04.Wild_Farm.Core;

namespace _04.Wild_Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
